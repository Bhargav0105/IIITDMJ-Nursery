
FIRST CREATE A DATABASE WITH NAME AS "iiitdmj_nursery",AND IMPORT THE SQL FILE WHICH IS PROVIDED.


ADMIN CREDINTIALS:
a)
ADMINID---Bhargav_0105---
PASSWORD---20BCS138---
b)
ADMINID---VVSDC---
PASSWORD---20BCS244---
c)
ADMINID---MTK---
PASSWORD---20BCS132---

USER CREDINTIALS:
a)
USERID---Bhargav_0105---
PASSWORD---NBC---


NOTE:ALL THE SCREENSHOTS ATTACHED IN THE DOCUMENT ARE FROM THE USERID "Bhargav_0105". 

ABOUT OUR NURSERY :
IIITDMJ Nursery is a retail nursery that delivers plants and seeds to general public for home as well as for commercial garden purposes. We’ve assured a 24/7 support online chatbot for queries regarding plants, their care and delivery. We provide every details of each product about favourable climatic conditions for maximum yield as well as kind of soil and amount of watering required.

PURPOSE OF OUR PROJECT :

The main purpose of IIITDMJ nursery is to promote greenery by selling plants at minimal prices. As we provide details about optimum temperatures and kind of soil under which a plant gives maximum yield, people can chose plants according to the region they belong to and their climatic conditions.

SCOPE OF OUR PROJECT:

There is a lot of scope with this project as we can encourage and improve greenery an attract people to buy plants from our website particularly people who belong to those areas where natural plantation is slow. It also saves some time and money for the people as planting seeds and taking care of them takes a lot of time and effort.

CHATBOT :
We’ve added a 24/7 support chatbot facility which clarifies queries regarding delivery, products as well as transaction

issues to make website much more user friendly and easy to use for everyone.

SYSTEM FEATURES AND REQUIREMENTS:

->RAM : 512MB and Above
->Operating System : Windows 7,Windows 10,Mac or Most Linux distros released after 2017.
->Processor : Intel core i3 4th generation or higher, Ryzen 3 or higher.
->Hard disk : 20GB and above.
->Back end : PHP My-Admin
->Database : MySQL
->Browser : Chrome, Firefox or any modern browser.

FUNCTIONAL REQUIREMENTS:

A user must have an account to access the products, ask queries regarding products and purchase them. A user can update his contact number or address whenever he/she wants in the profile.

NON-FUNCTIONAL REQUIREMENTS:

A user will not be able to change his name after creating an account. A user cannot change any details regarding products.

TECHNOLOGIES USED:

FRONT END :

->HTML 5
->CSS
->BOOTSTRAP 4

BACKEND:
->PHP
->MySQL

SOFTWARE USED:
->Xampp/Wampp
->VS Code/Text-Editor


QUERIES AND FUNCTIONALITY:

1. In order to purchase the plants, users must login using username and password in which user name will be used as a key. If details of username or password are wrong then the user will be given a warning to enter correct details or sign up if the user is new to the website.

2.A username is unique and during sign up,if username of a user matches with another username then the user will be informed that an account already exists with such user name. Details of user will be recorded in customer table.

3.After logging in, the user will be directed to main page where the user can check products and their descriptions. The user can use chatbot for queries and can order the plants after logging in.

4.Users can either pay using the COD(Cash on delivery) or card methods while ordering. And then after transaction is successful the user will be given a message that the order is successful and the user will be given a bill.

5.Admins can login using log-in as admin button in login page. An admin can view all the orders and can update stocks as well as can add or delete products.