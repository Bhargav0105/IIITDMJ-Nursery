
  document.queryselector("#btn1").click(function(){
    console.log("Clicked");
  })
